from .evkbmimxrt1060 import Board
from .evkbimxrt1050 import Board